import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //version 1.0
        System.out.println("Hello, ");
        System.out.println("my ");
        System.out.println("name ");
        System.out.println("is ");
        System.out.println("Yura");
        //version 2.0
        String name = "Yura";
        System.out.print("Hello, my name is " + name + "\n");
        //version 3.0
        System.out.printf("Hello, my name is %s", "Yura" +"\n");
        //version 4.0
        //add input method
        Scanner scanner = new Scanner(System.in);
        //init variable String
        String myName = scanner.nextLine();
        //print it
        System.out.println("Hello my name is " + myName);
    }
}